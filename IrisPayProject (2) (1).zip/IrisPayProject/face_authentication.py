import cv2
import time
import tkinter as tk
from tkinter import messagebox

# Initialize the main Tkinter window
root = tk.Tk()
root.withdraw()  # Hide the main window as we are using only the pop-ups

def detect_face(frame, face_cascade):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

    return len(faces) > 0  # Return True if at least one face is detected

def face_scan():
    # Show initial warning message
    messagebox.showinfo("Info", "Please keep your face within the frame for 5 seconds.")

    # Load Haarcascades for face detection
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    # Open the camera
    cap = cv2.VideoCapture(0)

    start_time = time.time()
    duration = 5  # 5 seconds for scanning

    while time.time() - start_time < duration:
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame.")
            break

        if not detect_face(frame, face_cascade):
            messagebox.showerror("Error", "Face not detected! Please try again.")
            cap.release()
            cv2.destroyAllWindows()
            return False

        elapsed_time = int(time.time() - start_time)
        remaining_time = duration - elapsed_time

        cv2.putText(frame, "Scanning your face...", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(frame, f"Time left: {remaining_time}s", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)

        cv2.imshow("Face Scan", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    return True  # Return True if the face scan was successful

# Start the face scan process
if face_scan():
    print("Face scan successful!")
    messagebox.showinfo("Success", "Face scan successful!")
else:
    print("Face scan failed.")
    messagebox.showerror("Error", "Face scan failed.")
