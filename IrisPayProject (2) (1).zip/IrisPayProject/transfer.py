from web3 import Web3

# Connect to local Ganache instance
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

# Check connection
if not w3.is_connected():
    print("Failed to connect to Ganache.")
    exit()

# User inputs (without sending transactions)
sender_address = input("Enter sender address: ")
receiver_address = input("Enter receiver address: ")
amount_in_ether = float(input("Enter amount in Ether to send: "))
# Private key is not used in this script as sending transactions is not supported

# Convert amount to Wei
amount_in_wei = w3.to_wei(amount_in_ether, 'ether')

# Display transaction details (without sending the transaction)
print(f"Transaction Details:")
print(f"From: {sender_address}")
print(f"To: {receiver_address}")
print(f"Amount: {amount_in_ether} ETH ({amount_in_wei} Wei)")
print(f"Gas: 21000")
print(f"Gas Price: 20 Gwei")
print(f"Nonce: {w3.eth.get_transaction_count(sender_address)}")
print(f"Chain ID: 1337")
