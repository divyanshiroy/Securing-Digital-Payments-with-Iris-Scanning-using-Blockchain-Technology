from flask import Flask, render_template, request, jsonify, redirect, url_for
from web3 import Web3
import subprocess
import json

app = Flask(__name__)

# Set up Web3 connection
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

# Updated Ethereum addresses and private key
sender_address = '0x7e2831276Ba2844E8a2F58C7B19c2832B400378A'
receiver_address = '0x7f5Ee9249b31d3bFD6Eb89ac9383D365D4951964'
sender_private_key = '0xaed8249bf30516418bfaef0414e4244c52364d92cbcf99e863380eaeef6c1a08'

@app.route('/')
def index():
    return render_template('send_money.html')

@app.route('/start-iris-scan', methods=['POST'])
def start_iris_scan():
    try:
        # Run the iris scan script
        result = subprocess.run(['python', 'iris_scan.py'], capture_output=True, text=True)

        if "Iris scan successful" in result.stdout:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'error': 'Iris scan failed'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/send-money', methods=['POST'])
def send_money():
    try:
        # Capture form data from the POST request
        recipient = request.form['recipient']
        amount = float(request.form['amount'])

        # Validate recipient address and amount
        if not Web3.is_checksum_address(recipient):
            return jsonify({'success': False, 'error': 'Invalid recipient address'})
        if amount <= 0:
            return jsonify({'success': False, 'error': 'Invalid amount'})

        # Convert amount to Wei using the w3.eth module
        amount_in_wei = w3.to_wei(amount, 'ether')

        # Get the transaction count (nonce)
        nonce = w3.eth.get_transaction_count(sender_address)

        # Create transaction
        tx = {
            'to': recipient,
            'value': amount_in_wei,
            'gas': 21000,
            'gasPrice': w3.eth.gas_price,
            'nonce': nonce,
        }

        # Sign the transaction
        signed_tx = w3.eth.account.sign_transaction(tx, private_key=sender_private_key)

        # Send the signed transaction using the correct attribute
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)

        # Redirect to the success page with a success message
        return redirect(url_for('success', message=f"Transaction successful! TX Hash: {tx_hash.hex()}"))

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/success')
def success():
    # Fetch the message passed via the URL parameters
    message = request.args.get('message', 'Transaction completed successfully!')
    return render_template('success.html', message=message)

if __name__ == '__main__':
    app.run(debug=True)
