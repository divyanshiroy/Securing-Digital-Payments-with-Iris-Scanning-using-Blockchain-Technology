const wallet = require('ethereumjs-wallet').default;

// Generate a new wallet
const newWallet = wallet.generate();

// Get the private key and address
const privateKey = newWallet.getPrivateKeyString();
const address = newWallet.getAddressString();

console.log("Address:", address);
console.log("Private Key:", privateKey);
