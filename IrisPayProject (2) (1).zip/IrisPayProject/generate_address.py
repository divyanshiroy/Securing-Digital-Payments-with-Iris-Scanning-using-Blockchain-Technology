from web3 import Web3

# Connect to a Web3 provider (for address generation, this is not strictly necessary)
web3 = Web3()

# Generate a new private key and account
new_account = web3.eth.account.create()

# Extract the address and private key
new_address = new_account.address
new_private_key = new_account._private_key.hex()

print(f"Generated Ethereum address (to_address): {new_address}")
print(f"Generated private key: {new_private_key}")
