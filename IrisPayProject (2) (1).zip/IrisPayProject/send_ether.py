from web3 import Web3

# Connect to the Ganache CLI
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

if not w3.isConnected():
    raise ConnectionError("Failed to connect to Ganache.")

# Get list of accounts
accounts = w3.eth.getAccounts()
print(f"Available Accounts: {accounts}")

# Ask user to enter sender and receiver addresses
sender = input("Enter sender address: ").strip()
receiver = input("Enter receiver address: ").strip()

# Ask user for the amount to transfer
amount = float(input("Enter the amount in ETH to transfer: ").strip())
amount_in_wei = w3.toWei(amount, 'ether')

# Ensure the sender address is valid
if not w3.isAddress(sender):
    raise ValueError("Invalid sender address.")
# Ensure the receiver address is valid
if not w3.isAddress(receiver):
    raise ValueError("Invalid receiver address.")

# Get private key for the sender
private_key = input("Enter the private key for the sender: ").strip()

# Create the transaction
transaction = {
    'to': receiver,
    'value': amount_in_wei,
    'gas': 21000,
    'gasPrice': w3.toWei('20', 'gwei'),
    'nonce': w3.eth.getTransactionCount(sender),
}

# Sign the transaction
signed_txn = w3.eth.account.sign_transaction(transaction, private_key=private_key)

# Send the transaction
txn_hash = w3.eth.sendRawTransaction(signed_txn.rawTransaction)

# Wait for transaction receipt
txn_receipt = w3.eth.waitForTransactionReceipt(txn_hash)

print(f"Transaction successful with hash: {txn_hash.hex()}")
print(f"Transaction receipt: {txn_receipt}")
