import cv2
import time
import tkinter as tk
from tkinter import simpledialog, messagebox
from web3 import Web3

# Connect to Ganache or your Ethereum blockchain
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))

# Updated Ethereum addresses and private key
# Ensure sender and receiver addresses are among the ones provided by Ganache
sender_address = '0x7e2831276Ba2844E8a2F58C7B19c2832B400378A'  # Updated sender address
receiver_address = '0x7f5Ee9249b31d3bFD6Eb89ac9383D365D4951964'  # Updated receiver address
sender_private_key = '0xaed8249bf30516418bfaef0414e4244c52364d92cbcf99e863380eaeef6c1a08'  # Updated private key for the sender

# Initialize Tkinter window
root = tk.Tk()
root.withdraw()  # Hide main window for pop-ups only

def get_balance(address):
    return w3.from_wei(w3.eth.get_balance(address), 'ether')

def create_transaction(sender, receiver, amount):
    nonce = w3.eth.get_transaction_count(sender)
    gas_price = w3.eth.gas_price
    tx = {
        'nonce': nonce,
        'to': receiver,
        'value': w3.to_wei(amount, 'ether'),
        'gas': 21000,
        'gasPrice': gas_price,
        'chainId': 1337
    }
    return tx

def sign_transaction(tx, private_key):
    signed_tx = w3.eth.account.sign_transaction(tx, private_key)
    return signed_tx

def send_transaction(signed_tx):
    try:
        # Try with 'rawTransaction'
        tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
    except AttributeError:
        # Fallback to 'raw_transaction' if 'rawTransaction' is not found
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
    return tx_hash

def detect_eyes(frame, face_cascade, eye_cascade):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    eyes_detected = False

    for (x, y, w, h) in faces:
        roi_gray = gray[y:y + h, x:x + w]
        eyes = eye_cascade.detectMultiScale(roi_gray)
        if len(eyes) > 0:
            eyes_detected = True
            for (ex, ey, ew, eh) in eyes:
                center_x = x + ex + ew // 2
                center_y = y + ey + eh // 2
                cv2.circle(frame, (center_x, center_y), ew // 2, (0, 255, 0), 2)
    return eyes_detected

def iris_scan():
    # Show a warning message
    messagebox.showinfo("Info", "Please keep your eyes open during the scan.")

    # Load Haarcascades for face and eye detection
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')

    # Open the camera
    cap = cv2.VideoCapture(0)

    start_time = time.time()
    duration = 8  # 8 seconds for scanning

    ret, prev_frame = cap.read()
    if not ret:
        print("Error: Could not read initial frame.")
        cap.release()
        cv2.destroyAllWindows()
        return False

    while time.time() - start_time < duration:
        ret, curr_frame = cap.read()
        if not ret:
            print("Error: Could not read frame.")
            break

        if detect_eyes(curr_frame, face_cascade, eye_cascade):
            elapsed_time = int(time.time() - start_time)
            remaining_time = duration - elapsed_time

            cv2.putText(curr_frame, "Scanning...", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(curr_frame, f"Time left: {remaining_time}s", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
            cv2.imshow("Iris Scan", curr_frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    return True  # Return True if the iris scan was successful

def start_transaction():
    print("Starting iris scan and transaction process...")

    if iris_scan():
        print("Iris scan successful!")
        balance = get_balance(sender_address)

        # Ask user for the amount to send, default to 0.1 Ether
        amount = simpledialog.askfloat("Transaction", "Enter the amount of Ether to send (default: 0.1):", initialvalue=0.1)

        if amount is not None and balance >= amount:
            tx = create_transaction(sender_address, receiver_address, amount)
            signed_tx = sign_transaction(tx, sender_private_key)
            tx_hash = send_transaction(signed_tx)

            print(f"Transaction sent with hash: {tx_hash.hex()}")
            messagebox.showinfo("Success", f"Transaction successful!\n\nSender: {sender_address}\nReceiver: {receiver_address}\nAmount: {amount} ETH\nTransaction Hash: {tx_hash.hex()}\nAvailable Balance: {balance} ETH")
        else:
            messagebox.showerror("Error", f"Insufficient balance or invalid amount! Available balance: {balance} ETH")
    else:
        messagebox.showerror("Error", "Iris scan failed.")

start_transaction()